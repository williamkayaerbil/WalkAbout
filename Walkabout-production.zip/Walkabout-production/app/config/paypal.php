<?php


return    array(

		'API'=>array(

			'client_id'=>'AYXeNhCi82wmLTMjOVM9ZL9oKjGe7gemPViIV9ID0zjNt3es2fzsyl71wf3e',
			'secret'=>'EPvmMhCUb74Ua23T3gfFC5y1R7wpVlIGMqO3vWaiig8gCLbMVhhDRWTDGKUZ'
		),
		'config'=>array(
            'mode' => 'sandbox',
            'log.LogEnabled' => true,
            'log.FileName' => '../PayPal.log',
            'log.LogLevel' => 'FINE',
            'validation.level' => 'log',
            'cache.enabled' => true,
            // 'http.CURLOPT_CONNECTTIMEOUT' => 30
            // 'http.headers.PayPal-Partner-Attribution-Id' => '123123123'
        )

       );