<?php 
class WizardController extends BaseController{
    

    public function index(){
        return View::make('wizard.index');
    }


}