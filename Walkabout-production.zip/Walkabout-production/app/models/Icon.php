<?php

class Icon extends \Eloquent {

	public static $rules = [
		
	];

	// Don't forget to fill this array
	protected $fillable = ['name'];
	
}