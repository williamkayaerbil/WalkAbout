@extends('admin.index')
@section('content')

<img style="width:100%;height: 100%; margin-top: -70px;" src="{{asset('img/dashboard.png')}}">

@endsection