<div id="banner" style="background: none repeat scroll 0 0 #fff;
    left: 20px;
    opacity: 0.9;
    padding: 20px;
    position: absolute;
    top: 20px;
    z-index: 51;">
<h1>Map preview</h1>
<a href="{{$urlPaypal}}">Continue to paypal</a>
</div>