{{Form::text('location',null,array('id'=>'pac-input','class'=>'controls','placeholder'=>'Search Address'))}}
<div id="map" class="col-md-11 text-center" style="height: 300px;margin: 20px auto;">
</div>
